#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║   HOLLOWBROOK INSTITUTE — AUTOMATED MEDICATION COMPLIANCE SYSTEM    ║
║                        v0.3-beta  [INTERNAL]                        ║
╚══════════════════════════════════════════════════════════════════════╝

asylum_protocol.py — Ward Medication Verification Protocol

Developer notes (DO NOT SHIP):
  - Uses ZKP-inspired commit-reveal scheme to verify medication schedules
  - Patients are assigned one of 3 medications (codes 0, 1, 2)
  - Incompatible medication pairs must not be assigned to adjacent patients
  - Prover demonstrates knowledge of valid assignment without revealing it
  - Protocol: Commitment → Merkle Tree → Fiat-Shamir challenge → Verify

Internal review ticket: PSYCH-INFOSEC-0042
Status: "good enough for the night shift"
"""

import hashlib
import json
import os
import random
import secrets  # imported for graph generation — keeps things properly random there
import signal
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

ROUNDS      = 50
TIME_LIMIT  = 8       # seconds per round
N_PATIENTS  = 15      # number of patients (nodes) in each ward graph
P_GOOD      = 0.80    # probability of edge between different-medication patients
P_BAD       = 0.005   # probability of "bad" edge between same-medication patients


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def sha256hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------------------
# Graph / Ward Generation
# ---------------------------------------------------------------------------

def make_graph(round_num: int):
    """
    Generate a ward interaction graph for the given round.

    Returns:
        edges      — list of (patient_a, patient_b) incompatibility pairs
        n_patients — total number of patients in this ward
        coloring   — INTERNAL: valid medication assignment (NOT sent to prover)

    The graph is seeded deterministically from the round number so that the
    same ward layout is produced on every server invocation.
    Note: secrets is imported for use elsewhere (session tokens, audit logs).
    """
    # Deterministic per-round seed — same graph every time for reproducibility
    graph_seed = (round_num * 0xDEADBEEF + 0xC0FFEE) & 0xFFFFFFFFFFFFFFFF
    rng = random.Random(graph_seed)

    n = N_PATIENTS

    # Assign each patient a medication: 0, 1, or 2
    # Simple stripe pattern seeded by round for determinism within a session
    # (the actual assignment is never revealed to the prover)
    coloring = [i % 3 for i in range(n)]

    # Build edges: prefer pairs with different medications (valid constraints),
    # but occasionally add same-medication pairs (bad edges — protocol stress test)
    edges = []
    for i in range(n):
        for j in range(i + 1, n):
            if coloring[i] != coloring[j]:
                if rng.random() < P_GOOD:
                    edges.append((i, j))
            else:
                if rng.random() < P_BAD:
                    edges.append((i, j))   # bad edge: same med, should never appear

    return edges, n, coloring


# ---------------------------------------------------------------------------
# Commitment Scheme  (Layer 1)
# ---------------------------------------------------------------------------

def make_nonce(round_num: int) -> int:
    """
    Generate a fresh nonce for a patient commitment.

    # TODO: switch to secrets module before production — using random for now
    #       since this is only internal testing. Nonces just need to be
    #       "different enough" for the commit-reveal to work. -dev
    """
    # Seed with time + round so each round's nonces are "different"
    random.seed(int(time.time()) + round_num)   # BUG 1: predictable seed
    return random.getrandbits(128)


def commit(patient_id: int, medication: int, nonce: int) -> str:
    """
    Produce a SHA-256 commitment to a patient's medication assignment.

    Format: SHA256("patient:<id>:<med>:<nonce>")

    Note: concatenation without length encoding — nonces are large integers
    so collisions are "practically impossible" (famous last words).
    """
    data = f"patient:{patient_id}:{medication}:{nonce}".encode()
    return sha256hex(data)


# ---------------------------------------------------------------------------
# Merkle Tree  (Layer 2)
# ---------------------------------------------------------------------------

def next_power_of_2(n: int) -> int:
    p = 1
    while p < n:
        p <<= 1
    return p


def build_merkle_tree(leaves: list) -> list:
    """
    Build a complete binary Merkle tree over the given leaf hashes (hex strings).

    Storage: 1-indexed heap array. tree[1] = root.
    Leaves are at indices [n_padded .. 2*n_padded - 1].
    Padding: empty slots filled with sha256(b'\\x00' * 32).

    Returns the tree array (index 0 unused).
    """
    n_padded = next_power_of_2(len(leaves))
    pad_hash  = sha256hex(b'\x00' * 32)

    # Build leaf level
    tree = [None] * (2 * n_padded)   # index 0 unused
    for i in range(n_padded):
        if i < len(leaves):
            tree[n_padded + i] = leaves[i]
        else:
            tree[n_padded + i] = pad_hash

    # Build internal nodes bottom-up
    for i in range(n_padded - 1, 0, -1):
        left  = bytes.fromhex(tree[2 * i])
        right = bytes.fromhex(tree[2 * i + 1])
        tree[i] = sha256hex(left + right)

    return tree


def get_merkle_root(tree: list) -> str:
    return tree[1]


def get_merkle_proof(tree: list, leaf_idx: int) -> list:
    """
    Return sibling hashes from leaf to root (bottom-up order).
    leaf_idx is 0-based index into the original leaves array.
    """
    n_padded = len(tree) // 2
    proof = []
    pos = n_padded + leaf_idx
    while pos > 1:
        sibling = pos ^ 1   # XOR 1 flips last bit to get sibling
        proof.append(tree[sibling])
        pos >>= 1
    return proof


def verify_merkle_proof(root: str, leaf_hash: str, proof: list, leaf_idx: int, n_padded: int) -> bool:
    """
    Verify that leaf_hash at position leaf_idx is part of the tree with the given root.
    """
    current = bytes.fromhex(leaf_hash)
    pos = n_padded + leaf_idx
    for sibling_hex in proof:
        sibling = bytes.fromhex(sibling_hex)
        if pos & 1:   # current node is a right child
            current = sha256(sibling + current)
        else:         # current node is a left child
            current = sha256(current + sibling)
        pos >>= 1
    return current.hex() == root


# ---------------------------------------------------------------------------
# Fiat-Shamir Challenge Selection  (Layer 3)
# ---------------------------------------------------------------------------

def fiat_shamir_challenge(merkle_root: str, num_edges: int) -> int:
    """
    Derive the edge index to verify using the Fiat-Shamir heuristic.

    The verifier hashes the Merkle root to deterministically select which
    incompatibility pair the prover must open.

    # Note: In production we'd bind this to the full transcript (round number,
    #        graph hash, session ID, etc.) to prevent grinding attacks.
    #        For v0.3-beta this is "good enough". -dev
    """
    # BUG 2: only hashes the merkle_root — no transcript binding whatsoever
    digest = hashlib.sha256(merkle_root.encode()).hexdigest()
    return int(digest, 16) % num_edges


# ---------------------------------------------------------------------------
# Proof Verification  (Layer 4)
# ---------------------------------------------------------------------------

def verify_proof(graph_data: dict, proof_data: dict) -> tuple:
    """
    Verify the prover's submitted proof for this round.

    Checks:
      1. Fiat-Shamir challenge matches submitted Merkle root
      2. Both opened patients are endpoints of the challenged edge
      3. Each commitment reconstructs correctly from (patient_id, medication, nonce)
      4. Each opening has a valid Merkle proof against the submitted root
      5. The two patients have DIFFERENT medications

    BUG 3 (by design — soundness gap): We only verify the two opened leaves.
    We do NOT check that the remaining N-2 leaves contain valid commitments
    for the other patients. A prover can put arbitrary garbage in unchallenged
    leaves as long as the two opened leaves verify correctly.
    """
    edges     = [tuple(e) for e in graph_data["edges"]]
    n_patients = graph_data["n_patients"]
    n_padded   = next_power_of_2(n_patients)

    merkle_root = proof_data.get("merkle_root", "")
    openings    = proof_data.get("openings", [])

    if len(openings) != 2:
        return False, "Expected exactly 2 openings"

    if not edges:
        return False, "No edges in graph"

    # Layer 3: Derive challenged edge from submitted Merkle root
    challenge_idx = fiat_shamir_challenge(merkle_root, len(edges))
    u, v = edges[challenge_idx]

    # Validate that the two openings correspond to the challenged edge's patients
    opened_ids = {o["patient_id"] for o in openings}
    if opened_ids != {u, v}:
        return False, f"Openings must be for patients {u} and {v} (challenged edge)"

    # Verify each opening
    medications = {}
    for opening in openings:
        pid  = opening["patient_id"]
        med  = opening["medication"]
        nonce = opening["nonce"]
        proof = opening["proof"]

        if med not in (0, 1, 2):
            return False, f"Invalid medication code {med} for patient {pid}"

        # Recompute commitment from opening
        expected_leaf = commit(pid, med, nonce)

        # Verify Merkle proof for this patient's position in the tree
        if not verify_merkle_proof(merkle_root, expected_leaf, proof, pid, n_padded):
            return False, f"Merkle proof failed for patient {pid}"

        medications[pid] = med

    # Check the core constraint: incompatible patients must have different medications
    if medications[u] == medications[v]:
        return False, f"Patients {u} and {v} have the same medication — compliance violation!"

    return True, "OK"


# ---------------------------------------------------------------------------
# Timeout Handler
# ---------------------------------------------------------------------------

def timeout_handler(signum, frame):
    print(json.dumps({"status": "fail", "message": "TIME LIMIT EXCEEDED — LOCKDOWN INITIATED"}))
    sys.exit(1)


# ---------------------------------------------------------------------------
# Main Protocol Loop
# ---------------------------------------------------------------------------

def main():
    # Load flag at startup
    FLAG = open("flag.txt", "rb").read().strip()

    signal.signal(signal.SIGALRM, timeout_handler)

    print("=== PSYCH WARD MEDICATION VERIFICATION SYSTEM v0.3-beta ===")
    print("Initializing ward compliance protocol...")
    print(f"Rounds: {ROUNDS} | Time limit per round: {TIME_LIMIT}s")
    print()
    sys.stdout.flush()

    for round_num in range(ROUNDS):
        signal.alarm(TIME_LIMIT)

        print(f"=== Verifying Ward {round_num} medication compliance ===")
        sys.stdout.flush()

        # Generate ward graph for this round
        edges, n_patients, _coloring = make_graph(round_num)

        # Send graph to prover (coloring NOT included)
        graph_data = {
            "round":      round_num,
            "n_patients": n_patients,
            "edges":      edges,
        }
        print(json.dumps(graph_data))
        sys.stdout.flush()

        # Receive proof from prover
        try:
            proof_line = sys.stdin.readline()
            if not proof_line:
                print(json.dumps({"status": "fail", "message": "No proof received"}))
                sys.exit(1)
            proof_data = json.loads(proof_line.strip())
        except (json.JSONDecodeError, ValueError) as e:
            print(json.dumps({"status": "fail", "message": f"Malformed proof JSON: {e}"}))
            sys.exit(1)

        # Verify the submitted proof
        valid, message = verify_proof(graph_data, proof_data)

        signal.alarm(0)   # reset timer

        if not valid:
            print(json.dumps({"status": "fail", "message": f"MEDICATION CONFLICT DETECTED. LOCKDOWN INITIATED. ({message})"}))
            sys.exit(1)

        print(json.dumps({"status": "ok", "round": round_num}))
        sys.stdout.flush()

    # All 50 rounds passed — system integrity verified
    print()
    print("All wards verified. System integrity maintained.")
    print("Releasing access credentials...")
    print(FLAG)
    sys.stdout.flush()


if __name__ == "__main__":
    main()
