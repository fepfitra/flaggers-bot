```
╔══════════════════════════════════════════════════════════════════════════════╗
║         HOLLOWBROOK INSTITUTE FOR MENTAL WELLNESS — INTERNAL MEMO           ║
║                  TO: All Ward Staff  |  FROM: Dr. Oren Mast                 ║
║                  RE: New Automated Medication Verification System            ║
╚══════════════════════════════════════════════════════════════════════════════╝

  Distribution : RESTRICTED — Night Shift Supervisors Only
  Clearance    : Ward Level 2
  Ref No.      : PSYCH-INFOSEC-0042
  Date         : [REDACTED PER FACILITY POLICY]

──────────────────────────────────────────────────────────────────────────────
MEMO — AUTOMATED COMPLIANCE VERIFICATION PROTOCOL
──────────────────────────────────────────────────────────────────────────────

Effective immediately, all ward medication compliance checks will be handled
by our new automated system: the Psych Ward Medication Verification System,
v0.3-beta.

The system uses a "zero-knowledge"-inspired cryptographic protocol to verify
that each ward's medication schedule is correct, without ever transmitting
the full schedule in plaintext. This ensures patient confidentiality while
maintaining rigorous compliance standards.

In brief: the system commits to a medication assignment using cryptographic
hashes, organizes these commitments in a Merkle tree, then uses a
deterministic challenge function to select which patient pair to verify.
Only the challenged pair's data is revealed.

The protocol was implemented by our night-shift IT contractor, who assures
us it is "cryptographically sound for all practical purposes." Dr. Kettleburn
from the security review board has raised some concerns but has agreed to
table them until after the quarterly audit.

Note: The system was rushed to production. The developer's TODO comments
are still in the code. We have been assured this is "cosmetic only."

──────────────────────────────────────────────────────────────────────────────
CONNECTION DETAILS
──────────────────────────────────────────────────────────────────────────────

The system runs on the facility's internal network:

    nc 14.139.34.11 8087

You are given: asylum_protocol.py

The server will run 50 rounds of the verification protocol. Pass all rounds
to obtain the access credentials.

To run the server locally:

    python3 asylum_protocol.py

──────────────────────────────────────────────────────────────────────────────
DR. MAST — CLOSING NOTE
──────────────────────────────────────────────────────────────────────────────

Do not attempt to understand the cryptography. The contractor says it is
"industry standard." The voices in the code agree.

                                             — Dr. Oren Mast
                                               Chief of Psychiatry
                                               Hollowbrook Institute, Ward Administration
```

---

**Flag format: `psych{...}`**

*[This document is the property of the Hollowbrook Institute for Mental Wellness.
Unauthorized access to facility systems is a violation of policy, the contractor's
NDA, and probably your grip on sanity. You have been warned.]*
